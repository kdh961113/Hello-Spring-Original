package com.example.Alpha.beandefinition;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class BeanDefinitionTest {

    //AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(AppConfig.class);

    GenericApplicationContext ac = new GenericXmlApplicationContext("appConfig.xml");

    @Test
    @DisplayName("빈 설정 메타정보 확인")
    void findApplicationBean(){
        String[] beanDefinitionNames = ac.getBeanDefinitionNames();
        for (String beanDefinitionName : beanDefinitionNames){
            BeanDefinition beanDefinition = ac.getBeanDefinition(beanDefinitionName);

            if (beanDefinition.getRole() == BeanDefinition.ROLE_APPLICATION){
                System.out.println("beanDefinitionName = " + beanDefinitionName +
                        " beanDefinition = " +beanDefinition) ;
            }
        } // BeanDefintion을 직접 생성해서 Spring 컨테이너에 등록 할 수도 있다.
        //하지만 실무에서 BeanDefiniton을 직접 정의하거나 사용할 일은 거의 없다
        //BeanDefinition에 대해서는 너무 깊이 있게 이해하기 보다는, Spring이 다양한 설정 정보를
        //BeanDefinition으로 추상화 해서 사용하는 것 정도만 이해하면 된다.
        //가끔 Spring Code나 Spring 관련 Open source Code를 볼 때, BeanDefinition이라는 것이 보일 때가 있다.
        //이때 이러한 메커니즘을 떠올리면 된다.
    }

}
