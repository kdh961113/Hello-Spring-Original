package com.example.Alpha.autowired;

import com.example.Alpha.AutoAppConfig;
import com.example.Alpha.annotation.MainDiscountPolicy;
import com.example.Alpha.discount.DiscountPolicy;
import com.example.Alpha.member.Grade;
import com.example.Alpha.member.Member;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Primary;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
@MainDiscountPolicy
@Primary
public class AllBeanTest {
    @Test
    void findAllBean() {
        ApplicationContext ac = new AnnotationConfigApplicationContext(AutoAppConfig.class, DiscountService.class);
        DiscountService discountService = ac.getBean(DiscountService.class);
        Member member = new Member(1L, "userA", Grade.VIP);
        int discountPrice = discountService.discount(member, 10000,"fixDiscountPolicy");
        assertThat(discountService).isInstanceOf(DiscountService.class);
        assertThat(discountPrice).isEqualTo(1000);
    }
    static class DiscountService {
        private final Map<String, DiscountPolicy> policyMap;
        private final List<DiscountPolicy> policies;
        public DiscountService(Map<String, DiscountPolicy> policyMap, List<DiscountPolicy> policies) {
            this.policyMap = policyMap;
            this.policies = policies;
            System.out.println("policyMap = " + policyMap);
            System.out.println("policies = " + policies);
        }
        public int discount(Member member, int price, String discountCode) {
            DiscountPolicy discountPolicy = policyMap.get(discountCode);
            System.out.println("discountCode = " + discountCode);
            System.out.println("discountPolicy = " + discountPolicy);
            return discountPolicy.discount(member, price);
        }
    }
}
//로직 분석
//DiscountService는 Map으로 모든 DiscountPolicy를 주입받는다. 이때 fixDiscoutPolicy, rateDiscountPolicy가 주입된다.
//discount() 메서드는 discountCode로 fixDiscountPolicy가 넘어오면 map에서 fixDiscountPolcy Spring Bean을
//찾아서 실행한다. 물론 rateDiscountPolicy가 넘어오면 fixDiscountPolicy가 Spring Bean을 찾아서 실행한다.

//주입 분석
//Map<String, DiscountPolicy>: map의 key에 Spring Bean의 Name을 넣어주고 그 값으로 DiscountPolicy Type으로
//조회한 모든 Spring Bean을 담아준다.
//List<DiscountPolicy>: DiscountPolicy Type으로 조회한 모든 Spring Bean을 담아준다.
//만약 해당하는 Type의 Spring Bean이 없으면, Bean 컬렉션이나 Map을 주입한다.

