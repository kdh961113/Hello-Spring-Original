package com.example.Alpha.singleton.filter;

@MyIncludeComponent
public class BeanB {
}
