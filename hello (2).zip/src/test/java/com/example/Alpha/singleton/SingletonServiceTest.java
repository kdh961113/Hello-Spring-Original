package com.example.Alpha.singleton;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class SingletonServiceTest {


    @Test
    @DisplayName("싱글톤 패턴을 적용한 개체 사용")
    void singletonServiceTest(){
        //1. 조회: 호출 할 때 마다 같은 개체를 반환
        SingletonService singletonService1 = SingletonService.getInstance();
        //2. 조회: 호출 할 때 마다 같은 개체를 반환
        SingletonService singletonService2 = SingletonService.getInstance();

        //참조값이 같은 것을 확인
        System.out.println("singletonService1 = " + singletonService1);
        System.out.println("singletonService2 = " + singletonService2);

        //singletonSerive1 = SingletonService2
        assertThat(singletonService1).isSameAs(singletonService2);

        singletonService1.logic();
    }
    //private으로 new 키워드를 막아두었다. 호출 할 때 마다 같은 개체 인스턴스를 반환하는 것을 확인할 수 있다.
    //싱글톤 패턴의 문제점
    //싱글톤 패턴을 구현하는 code 자체가 많이 들어간다
    //의존관계상 클라이언트가 구체 class에 의존한다 -> DIP를 위반한다.
    //클라이언트가 구체 Class에 의존해서 OCP 원칙을 위반할 가능성이 높다.
    //테스트하기 어렵고 내부 속성을 변경하거나 초기화하기 어렵다.
    //private 생성자로 자식 Class를 만들기 어렵다. 결론적으로 유연성이 떨어진다. 안티패턴으로 불린다.

}
