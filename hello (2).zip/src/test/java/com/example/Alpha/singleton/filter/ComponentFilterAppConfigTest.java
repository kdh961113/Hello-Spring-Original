package com.example.Alpha.singleton.filter;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

public class ComponentFilterAppConfigTest {

    @Test
    void filterScan(){
        ApplicationContext ac = new AnnotationConfigApplicationContext(CompoentFilterAppConfing.class);
        BeanA beanA = ac.getBean("beanA",BeanA.class);
        assertThat(beanA).isNotNull();
        //beanA가 NULL이 아닌지 assertThat으로 검사

        assertThrows(
                NoSuchBeanDefinitionException.class,
                () -> ac.getBean("beanB", BeanB.class)
                //NoSuchBeanDefinitionException 예외처리
        );
    }

    @Configuration
    @ComponentScan(
            includeFilters = @Filter(type = FilterType.ANNOTATION,classes = MyIncludeComponent.class),
            excludeFilters = @Filter(type = FilterType.ANNOTATION,classes = MyExcludeComponent.class)
    )
    static class CompoentFilterAppConfing{

    }
    //includeFilter에 MyIncludeComponet 애노테이션을 추가해서 BeanA가 Spring Bean에 등록된다.
    //excludeFilters에 MyExcludeComponent 애노테이션을 추가해서 BeanB는 Spring Bean에 등록되지 않는다.
}
    //FilterType 옵션
    //ANNOTATION: 기본값, 애노테이션을 인식해서 동작한다. ex)org.example.SomeAnnotation
    //ASSIGNABLE_TYPE: 지정한 Type과 자식 Type을 인식해서 동작한다. ex) org.example.SomeClass
    //ASPECTJ: AspectJ 패턴 사용. ex) org.example..*Service+
    //REGEX: 정규 표현식. ex) org\.example\.Default.*
    //CUSTOM: TypeFilter 이라는 인터페이스를 구현해서 처리. ex) org.example.MyTypeFiler

