package com.example.Alpha.singleton.filter;

@MyExcludeComponent
public class BeanA {
}
