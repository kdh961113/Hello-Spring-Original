package com.example.Alpha.singleton;

import com.example.Alpha.AppConfig;
import com.example.Alpha.member.MemberService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import static org.assertj.core.api.Assertions.assertThat;

public class SingletonTest {

    @Test
    @DisplayName("Spring 없는 순수한 DI 컨테이너")
    void pureContainer(){
        AppConfig appConfig = new AppConfig();
        //1. 조회: 호출할 때 마다 개체를 생성
        MemberService memberService1 = appConfig.memberService();
        //appConfing Class의 memberService Bean을 MemberService interface에 대입하는 생성자

        //2. 조회: 호출할 때 마다 개체를 생성
        MemberService memberService2 = appConfig.memberService();

        //참조값이 다른 것을 확인
        System.out.println("memberService1 = " + memberService1);
        System.out.println("memberService2 = " + memberService2);

        //memberService =! memberService2
        assertThat(memberService1).isNotSameAs(memberService2);
        
        //Spring 없는 순수한 DI 컨테이너인 AppConfig은 요청을 할 때 마다 개체를 새로 생성한다.
        //트래픽이 초당 100이 나오면 초당 100개 개체가 생성되고 소멸된다 -> 메모리 낭비가 심하다.
        //해결 방안은 해당 개체가 딱 1개만 생성되고, 공유하도록 설계하면 된다 -> 싱글톤 패턴
    }

    @Test
    @DisplayName("Spring 컨테이너와 singleton")
    void springContainer(){

        //AppConfig appConfig = new AppConfig();

        ApplicationContext ac = new AnnotationConfigApplicationContext(AppConfig.class);
        MemberService memberService1 = ac.getBean("memberService", MemberService.class);
        MemberService memberService2 =  ac.getBean("memberService", MemberService.class);
        //MemerService Interface를 참조하는 memberService1과 memberService2는 Bean을 사용하므로 동일한 주소를 설정된다.
        //참조값이 다른 것을 확인
        System.out.println("memberService1 = " + memberService1);
        System.out.println("memberService2 = " + memberService2);

        //memberService =! memberService2
        assertThat(memberService1).isSameAs(memberService2);
        //Spring 컨테이너 덕분에 고객의 요청이 올 때 마다 개체를 생성하는 것이 아니라
        //이미 만들어진 개체를 공유해서 효율적으로 재사용할 수 있다.
        //예시) 다수의 Client에서 memberSerivce 요청을 하면 Spring DI 컨터테이너에서 memberSerice Bean에
        //접근을 하는데 Bean의 갯수가 복수가 아니라 하나의 MemberSerice Bean에 접근을 한다.
        //그러므로 Client에게 동일한 memberService를 반환하게 되는 것이다.
    }

}

