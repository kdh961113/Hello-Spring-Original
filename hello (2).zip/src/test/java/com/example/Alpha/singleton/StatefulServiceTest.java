package com.example.Alpha.singleton;


import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;

import static org.assertj.core.api.Assertions.*;


class StatefulServiceTest {

    @Test
    void statefulServiceSingleton(){
        ApplicationContext ac= new AnnotationConfigApplicationContext(TestCongig.class);
        StatefulService statefulService1 = ac.getBean(StatefulService.class);
        StatefulService statefulService2 = ac.getBean(StatefulService.class);
        //statefulService1와 statefulService2은 서로 같은 개체를 참조하고 있다.
        //즉 덮어쓰기 문제가 발생한다.

        //ThreadA: A사용자 10000원 주문
        //statefulServic Class에 접근, order의 int price에 값을 대입
        statefulService1.order("userA", 10000);

        //ThreadB: B사용자 20000원 주문
        //statefulServic Class에 접근, order의 int price에 값을 대입
        statefulService2.order("userB", 20000);

        //ThreadA: 사용자A가 주문 금액 조회
        int price =  statefulService1.getPrice();
        System.out.println("price = " + price);

        assertThat(statefulService1.getPrice()).isEqualTo(20000);
    }
    static  class  TestCongig {
        @Bean

        public StatefulService statefulService(){
            return new StatefulService();
        }
    }
    //ThreadA가 userA Code를 호출하고 ThreadB가 userB Code를 호출한다고 가정하였다.
    //StatefulService Class의 price 필드는 공유되는 필드인데, 특정 클라이언트가 값을 변경한다.
    //userA의 주문금액은 100000원이 되어야 하는데, 20000원이라는 결과가 나왔다.
    //공유필드는 조심해야 한다! Spring Bean은 항상 무상태(stateless)로 설계하자.

}