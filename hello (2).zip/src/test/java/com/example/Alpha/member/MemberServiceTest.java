package com.example.Alpha.member;

import com.example.Alpha.AppConfig;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MemberServiceTest {

    MemberService memberService; //interface 선언

    @BeforeEach
    public void beforeEach(){
        AppConfig  appConfig = new AppConfig();
        memberService = appConfig.memberService();
    }

    @Test
    void join(){
        //give
        Member member = new Member(1L,"memberA", Grade.VIP);
        //Grade Class의 enum VIP를 Member CLass의 member 생성자에 선언한다.

        //when
        memberService.join(member);
        //memberService CLass에 member의 값을 join 한다.

        Member findMember = memberService.findMember(1L);
        //Member class의 findMember 생성자에 memberSerive interface의 findMember 값을 대입
        //then
        Assertions.assertThat(member).isEqualTo(findMember);
        //assertThat과 isEqualTO 라이브러리를 사용하여 member와 findMember의 값을 동일한지 비교
    }

}
