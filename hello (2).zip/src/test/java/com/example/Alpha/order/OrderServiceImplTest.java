package com.example.Alpha.order;

import com.example.Alpha.discount.FixDiscountPolicy;
import com.example.Alpha.member.Grade;
import com.example.Alpha.member.Member;
import com.example.Alpha.member.MemoryMemberRepository;
import org.junit.jupiter.api.Test;


class OrderServiceImplTest {

    @Test
    void createOrder(){
        MemoryMemberRepository memberRepository = new MemoryMemberRepository();
        memberRepository.save(new Member(1L,"name", Grade.VIP));
        OrderServiceImpl orderService = new OrderServiceImpl(new MemoryMemberRepository(), new FixDiscountPolicy());
        orderService.createOrder(1L,"itemA",10000);

    }
    //생성자 주입을 선택하는 이유
    //불변
    //대부분의 의존관계 주입은 한번 일어나면 애플리케이션 종료시점까지 의존관게를 변경할 일이 없다.
    //오히려 대부분의 의존관계는 애플리케이션 종료 전까지 변하면 안된다.(불변해야 한다)
    //수정자 주입을 사용하면, setXxx 메서드를 public으로 열어두어야 한다.
    //누군가 실수로 변경할 수도 있고, 변경하면 안되는 메서드를 열어두는 것은 좋은 설계 방법이 아니다.
    //생성자 주입은 개체를 생성할 때 딱 1번만 호추되므로 이후에 호출되는 일이 없다. 따라서 불변하게 설계 가능

}