package com.example.Alpha.beanfind;

import com.example.Alpha.AppConfig;
import com.example.Alpha.member.MemberService;
import com.example.Alpha.member.MemberServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;

public class ApplicationContextBasicFindTest {

    AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(AppConfig.class);

    @Test
    @DisplayName("Bean Name으로 조회")
    void findBeanByName() {
        MemberService memberService = ac.getBean("memberService", MemberService.class);
        //MemberService Class의 Bean을 조회해서 MemberSerivice Interface에 주입시킨다.
        assertThat(memberService).isInstanceOf(MemberServiceImpl.class);
        //memberService Interface가 MemberServiceImpl Class의 인스턴스면 Assertion가 성공한다.

    }

    @Test
    @DisplayName("Name 없이 Type으로만 조회")
    void findBeanByType() {
        MemberService memberService = ac.getBean(MemberService.class);
        //name을 제거하고 Type으로만 조회한다.
        assertThat(memberService).isInstanceOf(MemberServiceImpl.class);
    }

    @Test
    @DisplayName("구체 Type으로 조회")
    void findBeanByName2() {
        MemberService memberService = ac.getBean("memberService", MemberServiceImpl.class);
        //Spring 컨테이너에 MemberSeriveImpl Class가 들어있으면 MemberService Interface에 작동함
        assertThat(memberService).isInstanceOf(MemberServiceImpl.class);
    }

    @Test
    @DisplayName("Bean Name으로 조회X")
    void findBeanByNameX() {
        //ac.getBean("XXXXX", MemberService.class);
        assertThrows(NoSuchBeanDefinitionException.class,
                () -> ac.getBean("XXXXX", MemberService.class));
        //예외를 던져주지 않으면 NoSuchBeanDefinitionException이라는 오류가 발생한다.
        //해당 오류는 예외처리 오류이다.
        //MemberSerive.class가 실행되면 NoSuchBeanDefinitionException Class, 즉 예외가 터져야 한다.
    }
}
