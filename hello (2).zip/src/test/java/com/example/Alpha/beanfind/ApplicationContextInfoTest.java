package com.example.Alpha.beanfind;

import com.example.Alpha.AppConfig;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ApplicationContextInfoTest {

    AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(AppConfig.class);

    @Test
    @DisplayName("모든 빈 출력하기")
    void findAllBean(){
        String[] beanDefinitionNames = ac.getBeanDefinitionNames();
        //Bean에 정의된 Name을 등록
        for (String beanDefinitionName : beanDefinitionNames){
            Object bean =  ac.getBean(beanDefinitionName);//beanDefinitionName에 저장된 Bean을 꺼낸다.
            System.out.println("name = " + beanDefinitionName + "object" + bean);
            //모든 Bean 출력하기, 실행하면 Spring에 등록된 모든 Bean 정보를 출력할 수 있다.
            //ac.getBeanDefinitonNames(): Spring에 등록된 모든 Bean Name을 조회한다.
            //ac.getBean(): Bean 이름으로 개체(인스턴스)를 조회한다.
        }
    }
    @Test
    @DisplayName("애플리케이션 빈 출력하기")
    void findApplicationBean() {
        String[] beanDefinitionNames = ac.getBeanDefinitionNames();
        for (String beanDefinitionName : beanDefinitionNames) {
            BeanDefinition beanDefinition = ac.getBeanDefinition(beanDefinitionName);

            //애플리케이션 Bean 출력하기, Spring이 내부에서 사용하는 Bean은 getRole()로 구분할 수 있다.
            //Role ROLE_APPLICATION: 직접 등록한 애플리케이션 Bean
            //Role ROLE_INFRASTRUCTURE : Spring이 내부에서 사용하는 Bean
            if (beanDefinition.getRole() == BeanDefinition.ROLE_APPLICATION) {
                Object bean =  ac.getBean(beanDefinitionName);
                System.out.println("name = " + beanDefinitionName + "object" + bean);
            }
        }
    }
}