package com.example.Alpha.lifecycle;


import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class NetworkClient {
    private String url;

    public NetworkClient(){
        System.out.println("생성자 호출, url = "+url);
    }

    public void setUrl(String url){
        this.url = url;
    }

    //서비스 시작시 호출
    public void connect(){
        System.out.println("connect: "+url);
    }

    public void call(String message){
        System.out.println("call: "+ url+" message = "+message);
    }
    //서비스 종료시 호출
    public void disconnect(){
        System.out.println("close " + url);

    }

    @PostConstruct
    public void init() {
        System.out.println("NetworkClient.init");
        connect();
        call("초기화 연결 메시지");
    }

    @PreDestroy
    public void close() {
        System.out.println("NetworkClient.close");
        disconnect();
    }
}
//"초기화, 소멸 Interface 단점"
//해당 Interface는 Spring 전용 Interface이다. 해당 Code가 Spring 전용 Interface에 의존한다.
//초기화, 소멸 메서드의 이름을 변경할 수 없다.
//내가 Code를 고칠수 없는 외부 라이브러리에 적용할 수 없다.
//Interface를 사용하는 초기화, 종료 방법은 Spring 초창기에 나온 방법들이고, 지금은 더 나은 방법들이 있어서 거의 사용하지 않는다.

//@PostConstruct, @PreDestory 이 두 애노테이션을 사용하면 가장 편리하게 초기화와 종료를 실행 할 수 있다.

//@PostConstruct, @PreDestory 애노테이션 특징
//최신 Spring에서 가장 권장되는 방법이다.
//애노테이션 하나만 붙이면 되므로 매우 편리하다.
//패키지를 잘 보면 'javax.annotation.PostConstruct'이다.
//Spring에 종속적인 기술이 아니라 JSP-250라는 Java 표준이다. 따라서 Spring이 아닌 다른 컨테이너에서도 동작한다.
//컴포넌트 Scan과 잘 어울린다.
//유일한 단점은 외부 라이브러리에는 적용하지 못한다는 것이다. 외부 라이브러리를 초기화, 종료 해야 하면 @Bean의 기능을 사용하자.

//정리
//@PostConstruct, @PreDestory 애노테이션을 사용하자
//Code를 고칠 수 없는 외부 라이브러리를 초기화, 종료해야 하면 '@Bean'의 'initMethod', 'destoryMethod'를 사용하자.
