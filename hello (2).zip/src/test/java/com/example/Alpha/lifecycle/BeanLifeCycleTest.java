package com.example.Alpha.lifecycle;

import org.junit.jupiter.api.Test;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

public class BeanLifeCycleTest {

    @Test
    public void lifeCycleTest(){
    ConfigurableApplicationContext ac = new AnnotationConfigApplicationContext(LifeCycleConfig.class);
    NetworkClient client = ac.getBean(NetworkClient.class);
    ac.close();


    }
    @Configuration
    static class LifeCycleConfig{

        //@Bean(initMethod = "init", destroyMethod = "close")

        //"Setting Information(설정 정보) 사용 특징
        //매서드 Name을 자유롭게 줄 수 있다. Spring Bean이 Spring Code에 의존하지 않는다.
        //Code가 아니라 Setting Information을 사용하기 때문에 Code를 고칠 수 없는 외부 라이브러리에도 초기화, 종료 메서드를 적용할 수 있다.

        //"종료 메서드 추론"
        //@Bean의 destoryMethod 속성에는 아주 특별한 기능이 있다.
        //라이브러리는 대부분 close, shutdown 이라는 Name의 종료 메서드를 사용한다.
        //@Bean의 destoryMethod는 기본값이 (inferred)(추론)으로 등록되어 있다.
        //이 추론 기능은 close, shutdown라는 이름의 메서드를 자동으로 호출해준다.
        //Name 그대로 종료 메서드를 추론해서 호출 해준다.
        //따라서 직접 Spring Bean으로 등록하면 종료 메서드는 따로 적어주지 않아도 잘 동작한다.
        //추론 기능을 사용하기 싫으면 destoyMethod ="" 처럼 빈 공백을 지정하면 된다.

        @Bean
        public NetworkClient networkClient(){
            NetworkClient networkClient = new NetworkClient();
            networkClient.setUrl("http://Alpha-spring.dev");
            return networkClient;
        }
    }
}

//Spring Bean은 간단하게 다음과 같은 LifeCycle를 가진다.
//"개체 생성" -> "의존관계 주입"
//Spring Bean은 개체를 생성하고, 의존관계 주입이 다 끝난 다음에야 필요한 Data를 사용 할 수 있는 준비가 완료됨.
//따라서 초기화 작업은 의존관계 주입이 모두 완료가 되고 난 다음에 호출해야 한다.
//Spring은 의존관계 주입이 완료되면 Spring Bean에게 CallBack 메서드를 통해서 초기화 시점을 알려주는 다양한 기능 제공
//또한 Spring은 Spring 컨테이너가 종료되기 직전에 소멸 CallBack를 준다. 따라서 안전하게 종료 작업을 진행할 수 있다.

//"Spring Bean의 Event LifeCycle"
//"Spring 컨테이너 생성" -> "Spring Bean 생성" -> "의존관계 주입" -> "초기화 CallBack" -> "사용" -> "소멸전 CallBack" -> "Spring Exit"

//"초기화 CallBack": Bean이 생성되고, Bean의 의존관계 주입이 완료된 후 호출
//"소멸전 CallBack": Bean이 소멸되기 직전에 호출

//개체의 생성과 초기화를 분리하자
//생성자는 필수정보(파라미터)를 받고, 메모리를 할당해서 개체를 생성하는 책임을 가진다. 반면에 초기회는 이렇게 생성된
//값들을 활용해서 외부 커넥션을 연결하는 무거운 동적을 수행한다.
//따라서 생성자 안에서 무거운 초기화 작업을 함께 하는 것 보다는 개체를 생성하는 부분과 초기화하는 부분을 명확하게
//나누는 것이 유지보수 관점에서 좋다. 물론 초기화 작업이 내부 값들만 약간 변경하는 정도로 단순한 경우에는
//생성자에서 한번에 다 처리하는게 더 나을 수 있다.

//Spring은 크게 3가지 방법으로 Bean 생명주기 CallBack을 지원한다.
//InterFace(InitializingBean, DisposableBean)
//설정 정보에 초기화 메서드, 종료 메서드 지정
//@PostConstruct, @PreDestory 에노테이션 지원