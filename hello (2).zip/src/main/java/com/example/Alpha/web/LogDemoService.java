package com.example.Alpha.web;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LogDemoService {

    private final MyLogger myLogger;
    public void logic(String id) {
        myLogger.log("service id = " + id);
    }
}

//비지니스 로직이 있는 서비스 계층에서도 Log를 출력해보자.
//여기서 중요한 점이 있다. request scope를 사용하지 않고 파라미터로 이 모든 정보를 Service 계층에 넘긴다면
//파라미터가 많아서 지저분해진다. 더 문제는 requestURL 같은 Web과 관련된 정보가 Web에 관련없는 Service 계층까지 넘어가게 된다.
//Web과 관련된 부분은 컨트롤러까지만 사용해야 한다.
//Service 계층은 Web 기술에 종속되지 않고, 가급적 순수하게 유지하는 것이 유지보수 관점에서 좋다.
//request scope의 MyLogger 덕분에 이런 부분을 파라미터로 넘기지 않고, MyLogger의 멤버변수에 저장해서 Code와 게층을 깔끔하게 유지할 수 있다.

//ObjectProvider 덕분에 ObjectProvider.getObject()를 호출하는 시점까지 request scope Bean 생성을 지연 할 수 있다.
//ObjectProvider.getObject()를 호출하는 시점에는 HTTP 요청이 진행중이므로 request scope Bean의 생성이 정상 처리된다.
//ObjectProvider.getObject()를 LogDemoController, LogDemoService에서 각각 한번씩 따로 호출해도 같은 HTTP 요청이면 Spring Bean이 반환된다.

