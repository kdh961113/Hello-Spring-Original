package com.example.Alpha.web;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequiredArgsConstructor
public class LogDemoController {
    //request 스코프 예제 개발
    //동시에 여러 HTTP 요청이 오면 정확히 어떤 요청이 남긴 Log인지 구분하기 어렵다.
    //이럴때 사용하기 딱 좋은 것이 바로 request 스코프이다.

    private final LogDemoService logDemoService;
    private final MyLogger myLogger;
    @RequestMapping("log-demo")
    @ResponseBody
    public String logDemo(HttpServletRequest request) {
        String requestURL = request.getRequestURL().toString();
        myLogger.setRequestURL(requestURL);
        myLogger.log("controller test");
        logDemoService.logic("testId");
        return "OK";
    }
}

//Loger가 잘 작동하는지 확인하는 테스트용 컨트롤러이다.
//여기서 HttpServletRequest를 통해서 요청 URL를 받았다. requestURL 값 'http://localhost:8080/log-demo'
//이렇게 받은 requestURL 값을 myLogger에 저장해둔다.
// myLogger는 HTTP 요청 당 각각 구분되므로 다른 HTTP 요청 때문에 값이 섞이는 걱정은 하지 않아도 된다.
//컨트롤러에서 controller test 라는 Log를 남긴다.


