package com.example.Alpha;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

//컴포넌트 스캔을 사용할려면 먼저 @ComponentScan을 설정 정보에 붙여두면 된다.
//기존 AppConfig과는 다른게 @Bean으로 등록한 Class가 하나도 없다
//컴포넌트 스캔을 사용하면 @Configuration이 붙은 설정 정보도 자동으로 등록되기 때문에,
//AppConfig, TestConfig 등 앞서 만들어 두었던 설정 정보도 함께 등록되고, 실행되어 버린다.
//그래서 excludeFilters를 이용해서 설정정보는 컴포넌트 스캔 대상에서 제외하였다.

//컴포넌트 스캔은 이름 그대로 @Component 에노테이션이 붙은 Class를 스캔해서 Spring Bean으로 등독한다.
//@Configuration이 컴포넌트 스캔의 대상이 된 이유도 @Configuration Source Code에서 @Component 에노테이션이 붙어있기 때문
@Configuration
@ComponentScan(
        basePackages = "com.example.member",

        //basePackages: 탐색할 Package의 시작 위치를 지정한다. 이 패키지를 포함해서 하위 Package를 모두 탐색한다.
        //basePackages = {"hello.core", "hello.service"} 이렇게 여러 시작 위치를 모두 지정할 수도 있다.
        //basePackageClasses: 지정한 Class의 Package를 탐색 시작 위로 지정한다.
        //만약 지정하지 않으면 @ComponentScan이 붙은 Setting Information Class Package의 시작위치가 된다.
        //권장하는 방법: Package위치를 지정하지 않고, Setting information Class의 위치를 프로젝트의 최상단에 두는 것.
        //Spring 부트도 이 방법을 기본적으로 제공한다.

        excludeFilters = @ComponentScan.Filter(type =  FilterType.ANNOTATION, classes = Configuration.class)
        //Configuration.classzzz가 참조된 Class들은 필터링해서 제외함.
        // 즉 @Configuration이 참조된 AppConfig Class를 필터링해서 제외함.

)
public class AutoAppConfig {


}
