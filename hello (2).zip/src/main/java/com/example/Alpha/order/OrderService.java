package com.example.Alpha.order;

public interface OrderService {//주문 결과를 반환하는 interface
    Order createOrder(Long memberId, String iteName, int itemPrice);
}
