package com.example.Alpha.order;

import com.example.Alpha.annotation.MainDiscountPolicy;
import com.example.Alpha.discount.DiscountPolicy;
import com.example.Alpha.member.Member;
import com.example.Alpha.member.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderServiceImpl implements OrderService{
    //OrderService를 구현체로 상속받는 OrderServiceImpl 생성

    private final MemberRepository memberRepository;
    private final DiscountPolicy discountPolicy;

    //생성자 주입을 사용하면 filed에 final Keyword를 사용할 수 있다.
    // 그래서 생성자에서 혹시라도 값이 설정되지 않는 오류를 컴파일 시점에 막아준다.
    //수정자 주입을 포함한 나머지 주입 방식은 모두 생성자 이후에 호출되므로 filed에 final Keyword를 사용 할 수 없다.
    //오직 생성자 주입 방식만 final Keyword를 사용할 수 있다.

    //생성자 주입 방식을 선택하는 이유는 여러가지가 있지만, 프레임워크에 의존하지 않고
    //순수한 Java 언어의 특징을 잘 살리는 방법
    //기본으로 생성자 주입을 사용하고, 필수 값이 아닌 경우에는 수정자 주입 방식을 옵션으로 부여하면 된다.
    //생성자 주입과 수정자 주입을 동시에 사용할 수 있다.
    //항상 생성자 주입을 선택해야 한다. 그리고 가끔 Option이 필요하면 수정자 주입을 선택하고, filed 주입을 사용하지말자.

    
    @Autowired //생성자가 딱 1개만 있으면 @Autowired를 생략해도 자동 주입된다. 물론 Spring Bean에만 해당
    //filed 명 매핑은 먼저 Type 매칭을 시도하고 그 결과에 따라 여러 Bean이 있을때 추가로 동작하는 기능이다.
    //@Autowired 매칭 정리
    //타입 매칭, 타입 매칭의 결과가 2개 이상의 filed Name, 파라미터 Name으로 Bean Name 매칭
    public OrderServiceImpl(MemberRepository memberRepository, @MainDiscountPolicy DiscountPolicy discountPolicy) {
        this.memberRepository = memberRepository;
        this.discountPolicy = discountPolicy;
    }
    //생성자 선언, 생성자를 통해 할당, 생성자 주입 방식
    //이름 그대로 생성자를 통해서 의존 관계를 주입 받는 방법
    //특징 생성자 호출시점에 딱 1번만 호출되는 것이 보장된다.
    //불편, 필수 의존관계에 사용


   // private final MemberRepository memberRepository = new MemoryMemberRepository();
    //메모리 멤버
    // MemoryMemberRepository Class에 MemberRepository interface의 memberRepository의 값을 대입

   // private final DiscountPolicy discountPolicy = new FixDiscountPolicy();
    //수정된 가격
    // FixDiscountPoilcy Class에 DiscountPolicy interface의 discountPolicy의 값을 대입

    //private final DiscountPolicy discountPolicy = new RateDiscountPolicy();
    //변동된 가격
    //RateDiscountPolicy Class에 DiscountPolicy interface의 discountPolicy의 값을 대입

    @Override
    public Order createOrder(Long memberId, String iteName, int itemPrice) {
        Member member = memberRepository.findById(memberId);
        //주문생성이 요청이 되면 회원정보를 검색.
        int discountPrice = discountPolicy.discount(member, itemPrice);
        //할인의 대한 것은 discountPolicy interface가 전담하고 결과만 전달해줌.

        return new Order(memberId, iteName, itemPrice, discountPrice);
        //최종적으로 생성(할인)된 가격을 return

        //memberRepository와 FixDiscountPolicy를 구현체로 생성해서 사용
    }

    //테스트 용도
    public MemberRepository getMemberRepository(){
        return memberRepository;
    }

    //interface로만 사용하도록 구현됨.
    //설계 변경으로 OrderServiceImpl Class는 FixDiscountPolicy를 의존하지 않으며 DiscountPolicy interface를 의존한다.
    //OrderServiceImpl Class 입장에서는 생성자를 통해 어떤 구현 개체가 들어올지(주입될지) 알 수 없다.
    //OrderService Class의 생성자를 통해서 어떤 구현 객체를 주입할지는 오직 외부 Class인 AppConfing Class에서 결정
    //결과적으로는 OrderServiceImpl Class에는 MemoryMemberRepository Class, FixDiscountPolicy 개체의 의존관계가 주입된다.

}
