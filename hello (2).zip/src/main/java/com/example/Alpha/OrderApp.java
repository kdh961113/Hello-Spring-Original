package com.example.Alpha;

import com.example.Alpha.member.Grade;
import com.example.Alpha.member.Member;
import com.example.Alpha.member.MemberService;
import com.example.Alpha.order.Order;
import com.example.Alpha.order.OrderService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class OrderApp {
    public static void main(String[] args) {

       // AppConfig appConfig = new AppConfig();
       // MemberService memberService = appConfig.memberService();
       // OrderService orderService = appConfig.orderService();

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        MemberService memberService = applicationContext.getBean("memberService",MemberService.class);
        OrderService orderService = applicationContext.getBean("orderService",OrderService.class);
        //ApplicationContext를 Spring 컨테이너라 한다.
        //기존에는 개발자가 Appconfig Class를 사용해서 직접 개체를 생성하고 DI(의존성 주입)을 했지만, 해당 Code는
        //Spring 컨테이너를 통해서 사용한다.
        //Spring 컨테이너는 @Configuration이 붙은 AppConfig Class를 설정(구성) 정보로 사용한다.
        //여기서 @Bean이라 적힌 메서드(interface)를 모두 호출해서 반환된 개체를 Spring 컨테이너에 등록한다.
        //이렇게 스프링 컨테이너에 등록된 개체를 Spring Bean이라고 한다.
        //Spring Bean은 @Bean이 붙은 메서드(interface)의 명을 Spring Bean의 이름으로 사용한다.
        //이전에는 개발자가 필요한 개체를 Appconfing Class에 작성하여 직접 조회했지만, 이제부터는 Spring 컨테이너를 통해
        //필요한 Spring Brean(개체)를 찾아야 한다. Spring Bean은 applicationContext.getBean() 매서드를 사용해서 찾는다.
        //기존에는 개발자가 직접 Java Code로 모든 것을 했다면 이제부터는 Spring 컨테이너에 개체를 Spring Bean으로 등록하고
        //Spring 컨테이너에 Spring Bean을 찾아서 사용하도록 변경되었다.

        Long memberId =1L;
        Member member = new Member(memberId, "memberA", Grade.VIP);
        memberService.join(member);

        Order order = orderService.createOrder(memberId, "itemA", 10000);

        System.out.println("order =" + order);

    }
}
