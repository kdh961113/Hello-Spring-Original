package com.example.Alpha;

import com.example.Alpha.discount.DiscountPolicy;
import com.example.Alpha.discount.FixDiscountPolicy;
import com.example.Alpha.member.MemberRepository;
import com.example.Alpha.member.MemberService;
import com.example.Alpha.member.MemberServiceImpl;
import com.example.Alpha.member.MemoryMemberRepository;
import com.example.Alpha.order.OrderService;
import com.example.Alpha.order.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;


@Configurable
public class AppConfig {

    //@Bean memberService -> new MemoryMemberRepository();
    //@Bean orderService -> new MemoryMemberRepository();

    //call AppConfig.memberService
    //call AppConfig.memberRepository
    //call AppConfig.memberRepository
    //call AppConfig.orderService
    //call AppConfig.memberRepository

    //call AppConfig.memberService
    //call AppConfig.memberRepository
    //call Appconfig.orderService


    @Bean
    public MemberService memberService(){
        return new MemberServiceImpl(memberRepository());
        //MemberServiceImpl 개체를 생성한 다음에, MemoryMemberRepository를 사용한다는 의존성 주입(DI)
    }

    @Bean
    public MemberRepository memberRepository() {
        return new MemoryMemberRepository();
    }
    //MemoryMemberRepository 개체를 생성한 다음에, MemberRepository에 의존성(DI) 주입

    @Bean
    public OrderService orderService(){
        return new OrderServiceImpl(
                memberRepository(),
                discountPolicy());
    }//생성자를 통해서, MemoryMemberRepository와 FixDiscountPolicy 개체를 참조하도록 설정하고
    //설정된 OrderServiceImpl Class를 반환함.

    @Bean
    public DiscountPolicy discountPolicy(){
        return new FixDiscountPolicy();

        //할인 정책을 담당하는 구현 Class를 FixDiscountPolicy Class에서 RateDiscountPolicy Class로 변경했다.
        //할인 정책을 변경해도, 애플리케이션의 구성 역할을 담당하는 AppConfing만 변경하면 된다.
        //Client Code인 OrdetServiceImpl Class를 포함해서 "사용 영역"의 어떤 Code도 변경할 필요가 없다.
    }
}   //new MemoryMemberRepository() 라는 Code가 중복 제거되었다.
    // 이제는 MemoryMemberRepository Class를 다른 구현체로 변경 할 때 한 부분만 변경하면 된다.
    //AppConfig Class의 Code를 보면 역할과 구현 Class가 한눈에 들어온다.
    // 애플리케이션 전체 구성이 어떻게되었는지 빠르게 파악 할 수 있다.
