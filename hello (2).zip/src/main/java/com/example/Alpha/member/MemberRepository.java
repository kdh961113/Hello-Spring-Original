package com.example.Alpha.member;

import org.springframework.beans.factory.annotation.Autowired;

public interface MemberRepository {

    void save(Member member); //Memer을 저장하는 void
    @Autowired
    Member findById(Long memberId); //Memer의 id를 검색
}
