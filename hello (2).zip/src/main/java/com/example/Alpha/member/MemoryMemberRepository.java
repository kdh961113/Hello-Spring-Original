package com.example.Alpha.member;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
@Component
public class MemoryMemberRepository implements MemberRepository{

    //getset 설정

    private static Map<Long, Member> store = new HashMap<>();
    //store에서 Map 인터페이스 설정
    @Override
    public void save(Member member) {
        store.put(member.getId(), member); //오류처리 하지 않음, member를 get한다.

    }

    @Override
    public Member findById(Long memberId) {
        return store.get(memberId);
    }
    //member를 set한다.
}
