package com.example.Alpha.member;

import com.example.Alpha.AppConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MemberApp {

    public static void main(String[] args) {
        //AppConfig appConfig = new AppConfig();
        //MemberService memberService = appConfig.memberService();

        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        //AppConfing Class에 있는 설정, 즉 Spring이 AppConfing Class에 있는 Bean을 스프링 컨테이너에
        //모두 개체를 생성 및 참조하여 Spring이 관리하게 한다.
        //스프링 컨데이너는 @Configuration이 붙은 AppConfing를 설정(구성)정보로 사용한다.
        //여기서 @Bean이라 적힌 개체를 모두 호출해서 반환된 개체를 스프링 컨테이너에 등록한다.
        //이렇게 등록된 개체를 스프링 빈이라고 한다.

        MemberService memberService = applicationContext.getBean("memberService", MemberService.class);
        //MemberService class안에 있는 memberService라는 이름을 가진 개체를 검색한다.

            Member member = new Member(1L, "memberA", Grade.VIP);
            //Grade Class의 enum VIP를 Member Class의 생성자 member에 새로 생성함.
            memberService.join(member);
            //member의 생성된 값을 memberService interface에 대입

            Member findMember = memberService.findMember(1L);
            //Member Class의 Member 생성자의 값과 MemberApp Class의 memberService의 값을
            //interface MemberService를 통해 비교하면서 값을 찾는다.
            System.out.println("new member = "+member.getName());
            //member의 getName값을 출력
            System.out.println("find Member " + findMember.getName());
            //findMember의 getName값을 출력

        }

    private static class ApplicationContext {
    }
}

