package com.example.Alpha.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class MemberServiceImpl implements MemberService {

    //private final MemberRepository memberRepository = new MemoryMemberRepository();
    //추상화와 구체화 2개 모두를 의존하는 Code
    @Autowired
    private final MemberRepository memberRepository;

   // ac.getBean(MemberRepository.class)
    //이전에 AppConfig에서는 @Bean으로 직접 설정 정보를 작성했고, 의존관계도 직접 명시했다.
    //이제는 이런 설정 정보 자체가 없기 때문에, 의존관계 주입도 해당 Class안에서 해결해야 한다.
    //@Autowired는 의존관계를 자동으로 주입해준다.

    //생성자에 @Autowired를 지정하면, Spring 컨테이너가 자동으로 해당 Spring Bean을 찾아서 주입한다.
    //이때 기본 조회 전략은 Type이 같은 빈을 찾아서 주입한다.
    //getBean(MemberRepository.class와 동일하다고 이해하면 된다.
    @Autowired
    public MemberServiceImpl(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }//생성자 선언, 생성자를 통해서 memberRepository의 구현체에 뭐가 들어갈지를 선택하는 것


    public void join(Member member) {
        memberRepository.save(member);
        //Member Class의 member값을 join해서 memberRepository를 참조하여 덮어씌운다.

    }

    public Member findMember(Long memberId) {
        return memberRepository.findById(memberId);
    }
    //테스트 용도
    public MemberRepository getMemberRepository() {
        return memberRepository;
    }

}
    //설계 변경으로 'MemberSerice'은 'MemoryMemberRepository'를 의존하지 않는다!
    //단지 'MemberRepository' interface만 의존한다
    //MemberServiceImpl 입장에서 생성자를 통해 어떤 객체가 들어올지(주입될지)는 알 수없다.
    //MemberServiceImpl Class의 생성자를 통해서 어떤 구현 개체를 주입할지는 오직 외부('AppConing')에서 결정된다.
    //MemberServiceImpl Class는 이제부터 의존관계에 대한 고민은 외부에 맡기고 실행에만 집중하면 된다.

