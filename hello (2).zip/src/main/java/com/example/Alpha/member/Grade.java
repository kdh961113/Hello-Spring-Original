package com.example.Alpha.member;

public enum Grade {
    BASIC,
    VIP
}
