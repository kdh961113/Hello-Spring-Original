package com.example.Alpha.member;


import org.springframework.beans.factory.annotation.Autowired;

public interface MemberService {

    void join(Member member); //member을 join 하는 것
    @Autowired
    Member findMember(Long memberId); //memberID를
}
