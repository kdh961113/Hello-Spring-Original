package com.example.Alpha.discount;

import com.example.Alpha.member.Grade;
import com.example.Alpha.member.Member;
import org.springframework.stereotype.Component;

@Component
public class FixDiscountPolicy implements DiscountPolicy{
    //정액할인 정책을 구현하는 Class, DiscountPlolcy를 구현체로 상속

    private int discountFixAmount= 1000; //1000원 할인
    @Override
    public int discount(Member member, int price) {
        if(member.getGrade() == Grade.VIP) {
            //만약에 member의 getGrade의 값이 Grade Class의 enum VIP라면
            return  discountFixAmount; //discountFixAmount의 int값 10000을 return
        } else {
            return 0; //아니라면 0을 return
        }
    }
}
