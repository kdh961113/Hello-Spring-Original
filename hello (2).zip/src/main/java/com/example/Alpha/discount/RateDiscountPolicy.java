package com.example.Alpha.discount;

import com.example.Alpha.annotation.MainDiscountPolicy;
import com.example.Alpha.member.Grade;
import com.example.Alpha.member.Member;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@MainDiscountPolicy
//@Quilifer는 추가 구분자를 붙여주는 방법이다. 주입시 추가적인 방법을 제공하는 것이지 Bean Name을 변경하는 것은 아니다.
//@Quilifer 끼리 매칭
//Bean Name 매칭
//NoSuchBeanDefinitionException 예외 발생

@Primary
//@primary는 우선순위를 정하는 방법이다. @Autowired시에 여러 Bena이 매칭되면 @Primary가 우선권을 가진다.

//@Primary, @Qualifer 우선순위
//@primay는 기본값 처럼 동작하는 것이고, @Quilfier는 매우 상세하게 동작한다.
//Spring은 자동보다는 수동이, 넓은 범위의 선택권 보다는 좁은 범위의 선택권이 우선 순위가 높다.
//따라서 @Quilifier가 우선권이 높다.
public class RateDiscountPolicy implements DiscountPolicy{

    private int discountPercent = 10; //10% 할인
    @Override
    public int discount(Member member, int price) {
        if (member.getGrade() == Grade.VIP){
            return price* discountPercent / 100; // 할인률(int) return
        } else {
            return 0;
        }
    }
}
