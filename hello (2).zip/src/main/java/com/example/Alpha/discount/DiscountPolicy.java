package com.example.Alpha.discount;

import com.example.Alpha.member.Member;

public interface DiscountPolicy {
    
    // @return 할인 대상 금액
    int discount(Member member, int price);
    //Member Class의 member와 price 값을 파라미터로 지정)
}
