package hello.core.member;

import hello.core.AppConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;


class MemberServiceTbest {

  MemberService memberService;

  @BeforeEach
  public void beforeEach(){
    AppConfig appConfig = new AppConfig();
    memberService = appConfig.memberService();
  }
  //AppConfig Class 주입

    @Test
    void join() {
        //given
        Member member = new Member(1L,"memberA", Grade.VIP);
        //Member Class에 VIP라는 Member 개체를 대입

        //when
        memberService.join(member);
        //MemberService에 join 한다.
        Member findMember = memberService.findMember(1L);
        //memberService Interface에 회원 조회를 한다.

        //then
       assertThat(member).isEqualTo(findMember);
       //member class의 회원과 memberService의 회원과 동일한지 검증한다.
    }
}