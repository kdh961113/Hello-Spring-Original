package hello.core.order;


import hello.core.AppConfig;
import hello.core.member.MemberService;
import org.junit.jupiter.api.BeforeEach;

public class OrderServiceTest {

    MemberService memberService;
    OrderService orderService;

    @BeforeEach
    public void beforeEach(){
        AppConfig appConfig = new AppConfig();
        memberService = appConfig.memberService();
        orderService = appConfig.orderService();
    }
    //@BeforeEach는 각 Test를 실행하기 전에 호출된다.
}
