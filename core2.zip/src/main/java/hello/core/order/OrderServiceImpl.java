package hello.core.order;

import hello.core.discount.DiscountPolicy;
import hello.core.member.Member;
import hello.core.member.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
//@RequiredArgsConstructor
//Lombok 라이브러리가 제공하는 @RequiredArgsConstructor 기능을 사용하면
//final이 붙은 filed를 모아서 생성자를 자동으로 만들어준다.
//다음 Code에서는 보이지 않지만 실제 호출 가능하다.
//Lombok이 Java의 애노테이션 프로세서라는 기능을 이용해서 컴파일 시점에
//생성자 Code를 자동으로 생성해준다.
//실제 Class를 열어보면 다음 Code가 추가되어 있는 것을 알 수 있다.

public class OrderServiceImpl implements OrderService{

        private final MemberRepository memberRepository; //MemberRepository Interface를 참조
        private final DiscountPolicy discountPolicy; //DiscountPolicy Interface를 참조


    @Autowired
    public OrderServiceImpl(MemberRepository memberRepository, DiscountPolicy discountPolicy) {
        this.memberRepository = memberRepository;
        this.discountPolicy = discountPolicy;
    }

    //생성자 선언 및 주입
    
    //Singleton 테스트 용도
    public MemberRepository getMemberRepository(){
        return memberRepository;
    }

    @Override
    public Order createOrder(Long memberId, String itemName, int itemPrice) {
        Member member = memberRepository.findById(memberId); // 회원정보 검색
        int discountPrice = discountPolicy.discount(member, itemPrice);
        //discountPolicy에게 값을 전달하고 결과만 받음
        //Interface에 대입

        return new Order(memberId, itemName,itemPrice, discountPrice);
        //멤버, 아이템, 할인 값 반환
    }
    //설계 변경으로 OrderServiceImpl 은 FixDiscountPolicy 를 의존하지 않는다.
    //단지 DiscountPolicy Interface만 의존한다.
    //OrderServiceImpl 입장에서 생성자를 통해 어떤 구현 개체가 들어올지(주입될지)는 알 수 없다.
   // OrderServiceImpl 의 생성자를 통해서 어떤 구현 개체을 주입할지는 오직 외부( AppConfig Class)에서 결정한다.
    //OrderServiceImpl 은 이제부터 실행에만 집중하면 된다.
    //OrderServiceImpl 에는 MemoryMemberRepository , FixDiscountPolicy 개체의 의존관계가 주입된다.
}

/*
@Autowired 매칭 정리
1. Type 매칭
2. 타입 매칭의 결과가 2개 이상일 때 필드 명, 파라미터 명으로 빈 이름 매칭
 */
