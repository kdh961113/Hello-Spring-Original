package hello.core;

import hello.core.member.Grade;
import hello.core.member.Member;
import hello.core.member.MemberService;
import hello.core.order.Order;
import hello.core.order.OrderService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class OrderApp {

    public static void main(String[] args) {

        ApplicationContext applicationContext =
                new AnnotationConfigApplicationContext(AppConfig.class);
        //ApplicationContext를 Spring 컨테이너라 한다.
        //기존 코드에서는 Appconfing Class를 사용해서 직접 개체를 생성하고 DI 했지만, 이제부터는
        //Spring 컨테이너를 통해서 사용한다.
        MemberService memberService =
                applicationContext.getBean("memberService", MemberService.class);
        OrderService orderService =
                applicationContext.getBean("orderService", OrderService.class);
        long memberId = 1L;

        Member member = new Member(memberId, "memberA", Grade.VIP);
        memberService.join(member);
        Order order = orderService.createOrder(memberId, "itemA", 10000);
        System.out.println("order = " + order);
    }

        /*
        Spring 컨테이너는 @Configuration 이 붙은 AppConfig 를 설정(구성) 정보로 사용한다. 
        여기서 @Bean이라 적힌 메서드를 모두 호출해서 반환된 개체를 Spring 컨테이너에 등록한다. 
        이렇게 Spring 컨테이너에 등록된 개체를 Spring Bean이라 한다.
        Spring Bean은 @Bean 이 붙은 메서드의 명을 Spring Bean의 이름으로 사용한다. 
        ( memberService ,orderService )
        이전 코드에서는 필요한 개체를 AppConfig Class를 사용해서 직접 조회했지만, 
        이제부터는 Spring 컨테이너를 통해서 필요한 Spring Bean(개체)를 찾아야 한다.
        Spring Bean은 applicationContext.getBean() 메서드를 사용해서 찾을 수 있다.
        기존 코드에서는 Java Code로 모든 것을 했다면 이제부터는 Spring 컨테이너에 객체를 Spring Bean으로
        등록하고, Spring 컨테이너에서 Spring Bean을 찾아서 사용하도록 변경되었다.


       */

        /*
        AppConfig appConfig = new AppConfig();
        MemberService memberService = appConfig.memberService();
        OrderService orderService = appConfig.orderService();

        //AppConfig Class 주입

       long memberId = 1L;
        Member member = new Member(memberId, "memberA", Grade.VIP);
        //VIP 회원 생성

        memberService.join(member);
        //memer에 대입

        Order order = orderService.createOrder(memberId, "itemA",10000);
        // 주문을 생성하여 Order Class에 대입

        System.out.println("order = " + order);
        //주문 출력
    }
    */
}

