package hello.core;


import hello.core.discount.RateDiscountPolicy;
import hello.core.order.OrderServiceImpl;
import hello.core.discount.DiscountPolicy;
import hello.core.member.MemberRepository;
import hello.core.member.MemberService;
import hello.core.member.MemberServiceImpl;
import hello.core.member.MemoryMemberRepository;
import hello.core.order.OrderService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public MemberService memberService() {
        //SingleTon Test Code
        //1번
        System.out.println("call AppConfing.memberService");
        return new MemberServiceImpl(memberRepository());
    }
    @Bean
    public OrderService orderService() {
        //SingleTon Test Code

        //1번
        System.out.println("call AppConfig.orderService");
        return new OrderServiceImpl(
                memberRepository(),
                discountPolicy());
    }
    @Bean
    public MemberRepository memberRepository() {
        //SingleTon Test Code
        //2번? 3번?
        System.out.println("call AppConfig.memberRepository");
        return new MemoryMemberRepository();
    }
    @Bean
    public DiscountPolicy discountPolicy() {
        return new RateDiscountPolicy();
    }


   /* {
        public MemberService memberService () { //MemberService Interface 접근

        return new MemberServiceImpl(memberRepository());
        //MemberServiceImpl Class를 memberRepository Interface로 구현
    }

        public OrderService orderService () { //OrderService Interface에 접근
        return new OrderServiceImpl(
                memberRepository(),
                discountPolicy());
        //OrderService Class를 memberRepository, discountPolocy Interface로 구현
    }

        public MemberRepository memberRepository () // MemberRepository Interface에 접근
        {
            return new MemoryMemberRepository();
            //MemoryMemberRepository Class로 구현

        }

        public DiscountPolicy discountPolicy () { // DiscountPolicy Interface에 접근

        //return new FixDiscountPolicy();
        return new RateDiscountPolicy();
        //ReateDiscountPolicy Class로 구현
    }
        //AppConfing Class를 보면 역할과 구현 Class가 한눈에 들어온다.
        //애플리케이션 전체 구성이 어떻게 구성되어있는지 빠르게 파악할 수 있다.
        //AppConfig class 에서 할인 정책 역할을 담당하는 구현을 FixDiscountPolicy RateDiscountPolicy 객체로 변경했다.
        //이제 할인 정책을 변경해도, 애플리케이션의 구성 역할을 담당하는 AppConfig만 변경하면 된다.
        //Client Code인 OrderServiceImpl 를 포함해서 사용 영역의 어떤 Code도 변경할 필요가 없다.
        //구성 영역은 당연히 변경된다. 구성 역할을 담당하는 AppConfig를 애플리케이션이라는 공연의 기획자로생각하자.
        //공연 기획자는 공연 참여자인 구현 객체들을 모두 알아야 한다.
    } */
}

