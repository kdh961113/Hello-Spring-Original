package hello.core;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HelloLombok {

    private String name;
    private int age;

    public static void main(String[] args){
       HelloLombok helloLombok = new HelloLombok();
       helloLombok.setName("asdfas");

        System.out.println("helloLombok = " + helloLombok);
    }

    /*
    최근에는 생성자를 딱 1개 두고 @Autowired를 생략하는 방법을 주로 사용한다.
    여기에 Lombok 라이브러리의 @RequiredArgsConstructor과 함께 사용하면 기능은 다 제공하면서
    Code는 깔끔하게 사용할 수 있다.
     */
}
