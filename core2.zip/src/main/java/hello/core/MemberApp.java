package hello.core;

import hello.core.member.Grade;
import hello.core.member.Member;
import hello.core.member.MemberService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class MemberApp {

    public static void main(String[] args){

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        //ApplicationContext를 Spring 컨테이너라 한다.
        //ApplicationContext는 Interface이다.
        //Spring 컨테이너는 XML을 기반으로 만들 수 있고, 애노테이션 기반의 Java 설정 Class로 만들 수 있다.
        //기존의 코드의 사용방식은 애노테이션 기반의 Java 설정 Class로 Spring 컨테이너를 만든 것이다.
        MemberService memberService = applicationContext.getBean("memberService", MemberService.class);
        // ApplicationContext Interface의 구현체이다.
        Member member = new Member(1L,"memberA", Grade.VIP);
        memberService.join(member);

        Member findMember = memberService.findMember(1L);
        System.out.println("new member = " +member.getName());
        System.out.println("find Member = " + findMember.getName());


        /*
        AppConfig appConfig = new AppConfig();
        MemberService memberService = appConfig.memberService();

        Member member = new Member(1L, "memberA", Grade.VIP);
        //Member class의 구조체를 가져와 새로운 개체 Member 데이터에 대입

        memberService.join(member);
        //Member 개체의 데이터를 memberService Class에 대입

        Member findMember = memberService.findMember(1L);
        //Member Class의 멤버 ID와 memberService Interface의 ID가 서로 일치 한지 확인

        System.out.println("new member =" + member.getName());
        System.out.println("find Member = " + findMember.getName());
        */
    }
}
