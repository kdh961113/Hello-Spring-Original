package hello.core.member;

import org.springframework.stereotype.Component;

@Component
public interface MemberRepository {

   void save(Member member);

   Member findById(Long memberId);//회원 ID를 검색하는 인터페이스 속성
}
