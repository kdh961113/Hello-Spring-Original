package hello.core.scan.filter;

@MyExcludeComponent
public class BeanB {
}
